<!DOCTYPE HTML>

<html>
	<head>
		<title>Dopetrope by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		
		<link rel="stylesheet" href="css/main.css" />
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">
            <section id="header">
            <?php require "bloc/header.php"?>
            </section>		
					
				<section id="main">
					<div class="container">

							<div class="col-88 col-12-medium ">
								
								
								<!-- Content -->
								<article class="box post">
									<form action="">
                                         <!-- ЗДЕСЬ БЛОКИ ЮЗЕРОВ -->
                                    <label>поиск предметы</label>
                                    
										<select name="thing">
											<option>Английский</option>
											<option>Русский</option>
											<option>Математика</option>
											
										</select>
                                    </form>
                                     <!-- ЗДЕСЬ БЛОКИ ЮЗЕРОВ при нахождения их в бд-->
                                     <div class="box post">

                                     </div>
                                     
								</article>

							</div>
						</div>
					</div>
				</section>

		
				

			<!-- Footer -->
			
			<section id="footer">
				<?php require "bloc/footer.php"?>
					
			</section>

		</div>

	</body>
</html>